#-*- coding: utf-8 -*-

def hello1():
    print('Hello World1')

def hello2():
    print('Hello World2')
