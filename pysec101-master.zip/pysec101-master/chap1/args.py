#!/usr/bin/python
#-*- coding: utf-8 -*-

import sys

args1 = sys.argv[1] # 1つ目のコマンドライン引数
args2 = sys.argv[2] # 2つ目のコマンドライン引数

print('args1: %s' % args1)
print('args2: %s' % args2)
