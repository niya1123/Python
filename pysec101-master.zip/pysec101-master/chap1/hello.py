#!/usr/bin/python
#-*- coding: utf-8 -*-

print('Hello World')
