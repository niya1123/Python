f = open('/etc/hosts', 'rb')
data = f.read()
print(data.decode())
